package com.process;

import com.google.gson.Gson;
import model.Guest;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "guestServlet", urlPatterns = {"*.ajax"})

public class ProcessList extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       PrintWriter out  = response.getWriter();

       /*retrieve or create the session here*/
       HttpSession sess      = request.getSession();
       List<Guest> guestList = (List<Guest>)sess.getAttribute("guestList");
       if(guestList == null){
           guestList = new ArrayList<Guest>();
           sess      = request.getSession();
           sess.setAttribute("guestList",guestList);
       }

       /*get input and insert */
        String first = request.getParameter("first");
        String last  = request.getParameter("last");
        //add a new row
        guestList.add(new Guest(first,last));

        /*Convert and Pass to the Ajax*/
        String JSONguest;
        JSONguest = new Gson().toJson(guestList);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        out.write(JSONguest);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher view = request.getRequestDispatcher("index.jsp");
        view.forward(request,response);
    }
}
