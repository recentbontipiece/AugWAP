"use strict";
$(function () {
    $("#send").click(updateGuests);
});


function updateGuests(){
    var first = $("#first").val();
    var last  = $("#last").val();
    $.ajax("guest.ajax",{
        "type":"post",
        "data":{
            'first':first,
            'last':last
        }
    }).done(displayguest)
     .fail(errorguest);
}

function displayguest(data) {
    var result  = JSON.stringify(data);
    var jsonObj = JSON.parse(result);

    $("#guestList").empty();
    var html ='<ul>';
    for(var i = 0; i < jsonObj.length; i++)
    {
        console.log(jsonObj[i]['first']+" And "+jsonObj[i]['last']);
        html+='<li>'+jsonObj[i]['first']+" "+jsonObj[i]['last']+'</li>';
    }
    html +='</ul>';
    $("#guestList").append(html);
}



function errorguest() {
  $("#guestList").html("error after post");
}

